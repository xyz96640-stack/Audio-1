import express from 'express';
import http from 'node:http';
import { Server } from 'socket.io';
import { randomInt } from 'node:crypto';

const app = express();
app.get('/health', (_req, res) => res.json({ ok: true, service: 'live-audio-signaling' }));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.ALLOWED_ORIGIN?.split(',') ?? '*' }, transports: ['websocket'], maxHttpBufferSize: 1e5 });
const rooms = new Map();
const ROOM_TTL_MS = Number(process.env.ROOM_TTL_MS || 10 * 60 * 1000);
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newCode() { let s = ''; for (let i = 0; i < 6; i++) s += CODE_CHARS[randomInt(CODE_CHARS.length)]; return s; }
function cleanRoom(code) { const room = rooms.get(code); if (room && room.expiresAt < Date.now()) { io.to(room.host).emit('room-closed', {}); if (room.listener) io.to(room.listener).emit('room-closed', {}); rooms.delete(code); return null; } return room; }
function ackError(ack, error) { if (typeof ack === 'function') ack({ ok: false, error }); }
function relayToOther(socket, event, data) {
  const code = String(data?.code || '').toUpperCase(); const room = cleanRoom(code);
  if (!room || ![room.host, room.listener].includes(socket.id)) return;
  const other = socket.id === room.host ? room.listener : room.host;
  if (other) io.to(other).emit(event, data);
}
io.on('connection', (socket) => {
  socket.on('create-room', (_data, ack) => {
    let code; do { code = newCode(); } while (rooms.has(code));
    rooms.set(code, { host: socket.id, listener: null, expiresAt: Date.now() + ROOM_TTL_MS });
    socket.data.roomCode = code;
    ack?.({ ok: true, code, expiresInSeconds: Math.floor(ROOM_TTL_MS / 1000) });
  });
  socket.on('join-room', (data, ack) => {
    const code = String(data?.code || '').toUpperCase(); const room = cleanRoom(code);
    if (!room) return ackError(ack, 'Room not found or expired.');
    if (room.host === socket.id) return ackError(ack, 'Source cannot join its own room.');
    if (room.listener && room.listener !== socket.id) return ackError(ack, 'Room already has a listener.');
    room.listener = socket.id; room.expiresAt = Date.now() + ROOM_TTL_MS; socket.data.roomCode = code;
    ack?.({ ok: true, code, expiresInSeconds: Math.floor(ROOM_TTL_MS / 1000) });
    io.to(room.host).emit('peer-joined', {});
  });
  for (const event of ['offer', 'answer', 'ice-candidate']) socket.on(event, (data) => relayToOther(socket, event, data));
  socket.on('leave-room', (data) => {
    const code = String(data?.code || socket.data.roomCode || '').toUpperCase(); const room = rooms.get(code);
    if (!room) return;
    const other = socket.id === room.host ? room.listener : room.host;
    if (other) io.to(other).emit('peer-left', {});
    if (socket.id === room.host) { if (room.listener) io.to(room.listener).emit('room-closed', {}); rooms.delete(code); }
    else { room.listener = null; }
  });
  socket.on('disconnect', () => {
    const code = socket.data.roomCode; const room = code && rooms.get(code); if (!room) return;
    if (socket.id === room.host) { if (room.listener) io.to(room.listener).emit('room-closed', {}); rooms.delete(code); }
    else if (socket.id === room.listener) { room.listener = null; io.to(room.host).emit('peer-left', {}); }
  });
});
setInterval(() => { for (const code of rooms.keys()) cleanRoom(code); }, 30_000).unref();
const port = Number(process.env.PORT || 3000);
server.listen(port, '0.0.0.0', () => console.log(`Signaling server listening on :${port}`));
