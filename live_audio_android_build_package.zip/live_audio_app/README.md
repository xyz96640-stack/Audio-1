# Live Audio — Flutter + WebRTC starter (v0.1)

Consent-based, room-code audio streaming starter for Android and iOS. This is a source project scaffold, **not yet a tested or installable APK/IPA**. The current environment did not have Flutter/Dart installed, so native builds and device tests have not been run.

## What is included

- Flutter UI with Broadcast / Listen roles.
- Explicit microphone permission request and visible live/session status.
- Short-lived 6-character room codes, one source + one listener.
- WebRTC offer/answer and ICE candidate signaling.
- Hosted signaling service using Node.js and Socket.IO.
- Optional TURN relay deployment example using coturn.
- Consent confirmation in the recording UI.

## Important MVP limitations

This is the first implementation scaffold, not a feature-complete release:

- Remote-track recording is **not implemented**. The UI asks for consent, but enabling recording currently returns an explicit unsupported message. Do not represent this version as recording-capable.
- Microphone gain is a UI/control hook only; actual per-track gain requires a native audio-processing pipeline or supported WebAudio path.
- Playback volume is a UI/control hook only; app-local volume control needs a supported audio output gain implementation. Device system volume may be used as a temporary workaround, but this starter does not change it.
- Latency callback is a placeholder; RTT/latency statistics need to be read from WebRTC `getStats()` and mapped to the UI.
- Production TURN should use short-lived TURN REST credentials, TLS, rate limiting, monitoring, and abuse controls. The sample static TURN username/password is for development only.
- The sample server currently uses in-memory rooms; restarting it drops all rooms. Room expiry is 10 minutes and codes are not intended as strong identity verification. Add rate limits and stronger access controls before public deployment.
- Add app-store privacy disclosures, a clear stop control, and OS-required foreground microphone behavior before production release.

## Prerequisites

- Flutter stable SDK and Android Studio (Android SDK / Gradle)
- Xcode on macOS for iOS builds
- Node.js 20+ for signaling server
- A public HTTPS/WSS endpoint for signaling
- A public TURN server with UDP/TCP and preferably TLS reachability

## Create the native Flutter wrapper

From the parent folder, run:

```bash
flutter create --platforms=android,ios live_audio_native
```

Copy this project's `lib/` folder and `pubspec.yaml` into `live_audio_native/`, replacing generated files. Then:

```bash
cd live_audio_native
flutter pub get
```

Add the permission snippets from `android_setup/AndroidManifest.permissions.xml` and `ios_setup/Info.plist.snippet.xml` to the generated native files. Check current `flutter_webrtc` plugin setup instructions for any additional platform configuration required by the pinned version.

## Configure endpoint and TURN

Build with your deployed signaling endpoint:

```bash
flutter run \
  --dart-define=SIGNALING_URL=https://YOUR_DOMAIN \
  --dart-define=TURN_URL=turn:YOUR_TURN_DOMAIN:3478?transport=udp \
  --dart-define=TURN_USERNAME=YOUR_SHORT_LIVED_USERNAME \
  --dart-define=TURN_CREDENTIAL=YOUR_SHORT_LIVED_CREDENTIAL
```

The signaling server must be behind TLS in production (HTTPS/WSS). Do not ship long-lived TURN secrets inside a mobile app; expose an authenticated endpoint that issues short-lived TURN credentials and pass those at runtime.

## Run signaling locally

```bash
cd server
npm install
npm start
```

Health check: `http://localhost:3000/health`.

For Android emulator, the app's default signaling URL is `http://10.0.2.2:3000`. For a physical phone, set `SIGNALING_URL` to a reachable LAN address during development. For worldwide use, deploy behind HTTPS and use TURN reachable from public networks.

## First test sequence

1. Run signaling server.
2. Run the app on two physical devices if possible.
3. On device A, select Broadcast and start; grant microphone permission and note the room code.
4. On device B, select Listen and enter the code.
5. Verify live audio and the visible connection state.
6. Stop from either device and verify the source microphone is released.
7. Test different Wi-Fi/mobile networks; verify TURN relay fallback using server logs/WebRTC stats.

## Planned implementation milestones

1. **Scaffold + signaling/WebRTC baseline** (this archive): project structure, source/listener roles, temporary rooms, offer/answer/ICE.
2. **Native build and connectivity hardening:** generate platform wrappers, build APK, fix plugin/platform errors, test real devices, add TURN REST credentials.
3. **Audio controls:** implement real output gain, input gain, mute, speaker/headphone routing, and measured latency from WebRTC stats.
4. **Consent-based recording:** implement remote audio recording with explicit consent, persistent visible indicator, stop/delete flow, and storage permissions appropriate to each OS.
5. **Production security:** TLS, rate limiting, room abuse controls, short-lived access tokens, privacy policy, diagnostics, app-store readiness.

## Security notes

Use only with permission from the person whose microphone is being streamed. Do not hide the live indicator, bypass OS permissions, or enable recording without the informed consent of everyone involved. Use encrypted WebRTC and TLS signaling; never expose TURN credentials or deploy the development configuration unchanged.
