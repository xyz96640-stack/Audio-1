# Build the Android APK

This folder contains Flutter source code, not an APK. The current build environment has no Flutter/Dart or Android SDK/Gradle installation and no network access, so an APK cannot be compiled here.

## Build with GitHub Actions

1. Create a private GitHub repository and upload the contents of this folder.
2. Deploy the signaling server and TURN service for worldwide connectivity.
3. In repository **Settings → Secrets and variables → Actions → Variables**, add:
   - `SIGNALING_URL`: deployed HTTPS signaling URL, e.g. `https://audio.example.com`.
   - `TURN_URL`: TURN URI, e.g. `turn:turn.example.com:3478?transport=udp`.
4. In **Secrets**, add `TURN_USERNAME` and `TURN_CREDENTIAL` for short-lived TURN credentials.
5. Open **Actions → Build Android APK → Run workflow**.
6. Download the `live-audio-android-apk` artifact from the completed workflow run, unzip it, and install `app-release.apk`.

## Limitations

- This workflow is a build path, not a claim that the APK has been compiled or tested already.
- Worldwide connectivity requires deployed signaling and TURN services.
- Real microphone gain, app-local playback volume, measured latency, and the recording pipeline are still incomplete in this starter.
- Use only with the informed permission of the person whose microphone is streamed, and keep the live status visible.
