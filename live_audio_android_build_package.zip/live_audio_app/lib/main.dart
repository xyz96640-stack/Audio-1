import 'package:flutter/material.dart';
import 'audio_session.dart';

void main() => runApp(const LiveAudioApp());

class LiveAudioApp extends StatelessWidget {
  const LiveAudioApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Live Audio', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff6558d3), brightness: Brightness.dark), useMaterial3: true),
    home: const HomePage(),
  );
}

enum AppRole { broadcast, listen }

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _session = AudioSession();
  final _roomController = TextEditingController();
  AppRole _role = AppRole.broadcast;
  String _status = 'Not connected';
  String _roomCode = '';
  bool _live = false;
  bool _muted = false;
  bool _recording = false;
  double _volume = 0.8;
  double _gain = 1.0;
  String _latency = '—';

  @override void initState() { super.initState(); _session.onStatus = (s) { if (mounted) setState(() => _status = s); }; _session.onRoom = (c) { if (mounted) setState(() => _roomCode = c); }; _session.onLatency = (v) { if (mounted) setState(() => _latency = v == null ? '—' : '${v} ms'); }; }
  @override void dispose() { _roomController.dispose(); _session.dispose(); super.dispose(); }

  Future<void> _start() async {
    try {
      if (_role == AppRole.broadcast) {
        await _session.startBroadcast();
        setState(() { _live = true; });
      } else {
        final code = _roomController.text.trim().toUpperCase();
        if (code.length < 4) { _snack('Enter the room code from the source phone.'); return; }
        await _session.joinRoom(code);
        setState(() { _live = true; _roomCode = code; });
      }
    } catch (e) { _snack('Could not start: $e'); }
  }
  Future<void> _stop() async { await _session.stop(); if (mounted) setState(() { _live = false; _recording = false; _status = 'Stopped'; }); }
  void _snack(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Live Audio'), centerTitle: false, actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Icon(_live ? Icons.circle : Icons.circle_outlined, color: _live ? Colors.redAccent : Colors.grey, size: 12))) ]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_live ? (_role == AppRole.broadcast ? 'MICROPHONE LIVE' : 'LISTENING') : 'READY', style: TextStyle(color: _live ? Colors.redAccent : Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
        const SizedBox(height: 12), Text(_live ? 'Keep this indicator visible while audio is active.' : 'Stream live audio between devices you own or are authorized to use.', style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 18), SegmentedButton<AppRole>(segments: const [ButtonSegment(value: AppRole.broadcast, label: Text('Broadcast'), icon: Icon(Icons.mic)), ButtonSegment(value: AppRole.listen, label: Text('Listen'), icon: Icon(Icons.headphones))], selected: {_role}, onSelectionChanged: _live ? null : (s) => setState(() => _role = s.first)),
      ])),
      const SizedBox(height: 18),
      if (_role == AppRole.broadcast) ...[
        const Text('Source phone', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)), const SizedBox(height: 8),
        const Text('Starting will request microphone permission and create a temporary room.'), const SizedBox(height: 14),
        if (_roomCode.isNotEmpty) Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.outline), borderRadius: BorderRadius.circular(14)), child: Row(children: [const Icon(Icons.key), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('ROOM CODE'), SelectableText(_roomCode, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 4))])), IconButton(onPressed: () { _roomController.text = _roomCode; _snack('Room code copied into the local field.'); }, icon: const Icon(Icons.copy))])),
      ] else ...[
        const Text('Listener phone', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)), const SizedBox(height: 8), const Text('Enter the short-lived code shown on the source phone.'), const SizedBox(height: 12),
        TextField(controller: _roomController, textCapitalization: TextCapitalization.characters, maxLength: 8, decoration: const InputDecoration(labelText: 'Room code', border: OutlineInputBorder(), prefixIcon: Icon(Icons.key)), enabled: !_live),
      ],
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _live ? _stop : _start, icon: Icon(_live ? Icons.stop_circle : Icons.play_circle), label: Text(_live ? 'Stop session' : (_role == AppRole.broadcast ? 'Start broadcast' : 'Join and listen'))),
      const SizedBox(height: 20),
      Text('Controls', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
        Row(children: [const Icon(Icons.volume_up), const SizedBox(width: 12), const Expanded(child: Text('Playback volume')), Text('${(_volume * 100).round()}%')]),
        Slider(value: _volume, onChanged: (v) { setState(() => _volume = v); _session.setVolume(v); }),
        if (_role == AppRole.broadcast) ...[Row(children: [const Icon(Icons.tune), const SizedBox(width: 12), const Expanded(child: Text('Microphone gain')), Text('${_gain.toStringAsFixed(1)}×')]), Slider(min: 0, max: 2, divisions: 20, value: _gain, onChanged: (v) { setState(() => _gain = v); _session.setGain(v); }), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Mute microphone'), value: _muted, onChanged: (v) { setState(() => _muted = v); _session.setMuted(v); })],
        if (_role == AppRole.listen) SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Record received audio'), subtitle: const Text('Recording requires explicit consent from everyone involved.'), value: _recording, onChanged: !_live ? null : (v) async { if (v) { final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Recording consent'), content: const Text('Confirm that the source person has been informed and agrees to recording. A recording indicator will remain visible.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('I have consent'))])); if (ok != true) return; } try { await _session.setRecording(v); setState(() => _recording = v); } catch (e) { _snack('Recording is not available in this build: $e'); } }),
      ]))),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const Icon(Icons.network_check), title: const Text('Connection'), subtitle: Text(_status), trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Text('Latency'), Text(_latency, style: const TextStyle(fontWeight: FontWeight.bold))]))),
      const SizedBox(height: 12),
      const Text('Privacy: audio is transmitted only after you start a session. Stop the session to close the microphone connection. Recording must be explicitly enabled and agreed to by the people involved.', style: TextStyle(fontSize: 12, color: Colors.white70)),
    ])),
  );
}
