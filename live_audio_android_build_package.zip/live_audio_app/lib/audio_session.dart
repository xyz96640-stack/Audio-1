import 'dart:async';
import 'dart:math';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

/// Set this to your deployed HTTPS/WSS signaling endpoint before building.
const String signalingUrl = String.fromEnvironment('SIGNALING_URL', defaultValue: 'http://10.0.2.2:3000');
/// Development placeholders only. Use short-lived TURN REST credentials in production.
const String turnUrl = String.fromEnvironment('TURN_URL', defaultValue: '');
const String turnUsername = String.fromEnvironment('TURN_USERNAME', defaultValue: '');
const String turnCredential = String.fromEnvironment('TURN_CREDENTIAL', defaultValue: '');

class AudioSession {
  Function(String)? onStatus;
  Function(String)? onRoom;
  Function(int?)? onLatency;
  io.Socket? _socket;
  RTCPeerConnection? _pc;
  MediaStream? _localStream;
  MediaStream? _remoteStream;
  String? _room;
  bool _broadcast = false;
  bool _muted = false;
  bool _stopped = false;
  double _gain = 1;
  double _volume = 0.8;
  final List<RTCIceCandidate> _pendingIce = [];

  Map<String, dynamic> get _configuration => {
    'sdpSemantics': 'unified-plan',
    'iceServers': [
      {'urls': ['stun:stun.l.google.com:19302']},
      if (turnUrl.isNotEmpty && turnUsername.isNotEmpty && turnCredential.isNotEmpty)
        {'urls': [turnUrl], 'username': turnUsername, 'credential': turnCredential},
    ],
  };

  Future<void> _connectSocket() async {
    if (_socket?.connected == true) return;
    final s = io.io(signalingUrl, io.OptionBuilder().setTransports(['websocket']).disableAutoConnect().build());
    _socket = s;
    final completer = Completer<void>();
    s.onConnect((_) { if (!completer.isCompleted) completer.complete(); });
    s.onConnectError((e) { if (!completer.isCompleted) completer.completeError(Exception('Signaling connection failed: $e')); });
    s.connect();
    await completer.future.timeout(const Duration(seconds: 12));
    s.on('peer-joined', (_) async { if (_broadcast) await _makeOffer(); });
    s.on('offer', (data) async { await _receiveOffer(Map<String, dynamic>.from(data as Map)); });
    s.on('answer', (data) async { await _receiveAnswer(Map<String, dynamic>.from(data as Map)); });
    s.on('ice-candidate', (data) async { await _receiveIce(Map<String, dynamic>.from(data as Map)); });
    s.on('peer-left', (_) => onStatus?.call('Listener disconnected'));
    s.on('room-closed', (_) { onStatus?.call('Room closed'); stop(); });
    s.on('connect_error', (e) => onStatus?.call('Signaling error: $e'));
  }

  Future<void> startBroadcast() async {
    _stopped = false; _broadcast = true;
    final permission = await Permission.microphone.request();
    if (!permission.isGranted) throw Exception('Microphone permission is required to broadcast.');
    onStatus?.call('Requesting microphone…');
    _localStream = await navigator.mediaDevices.getUserMedia({'audio': {'echoCancellation': true, 'noiseSuppression': true, 'autoGainControl': false}, 'video': false});
    for (final track in _localStream!.getAudioTracks()) { track.enabled = !_muted; }
    await _connectSocket();
    final result = await _emitAck('create-room', {}).timeout(const Duration(seconds: 8));
    _room = result['code'] as String;
    onRoom?.call(_room!);
    await _createPeer();
    onStatus?.call('Microphone active · waiting for listener');
  }

  Future<void> joinRoom(String code) async {
    _stopped = false; _broadcast = false;
    await _connectSocket();
    final result = await _emitAck('join-room', {'code': code}).timeout(const Duration(seconds: 8));
    _room = (result['code'] as String).toUpperCase(); onRoom?.call(_room!);
    await _createPeer();
    onStatus?.call('Joined room · connecting audio');
  }

  Future<Map<String, dynamic>> _emitAck(String event, Map<String, dynamic> data) {
    final c = Completer<Map<String, dynamic>>();
    _socket!.emitWithAck(event, data, ack: (dynamic response) {
      final map = Map<String, dynamic>.from(response as Map);
      if (map['ok'] == true) { if (!c.isCompleted) c.complete(map); }
      else if (!c.isCompleted) c.completeError(Exception(map['error'] ?? 'Request failed'));
    });
    return c.future;
  }

  Future<void> _createPeer() async {
    _pc = await createPeerConnection(_configuration);
    _pc!.onIceCandidate = (candidate) { if (candidate.candidate != null && _room != null) _socket?.emit('ice-candidate', {'code': _room, 'candidate': candidate.toMap()}); };
    _pc!.onConnectionState = (state) {
      onStatus?.call(switch (state) { RTCPeerConnectionState.RTCPeerConnectionStateConnected => 'Connected · audio flowing', RTCPeerConnectionState.RTCPeerConnectionStateConnecting => 'Connecting…', RTCPeerConnectionState.RTCPeerConnectionStateDisconnected => 'Connection interrupted', RTCPeerConnectionState.RTCPeerConnectionStateFailed => 'Connection failed · check network/TURN', RTCPeerConnectionState.RTCPeerConnectionStateClosed => 'Disconnected', _ => 'Negotiating connection' });
    };
    _pc!.onTrack = (event) async {
      if (event.track.kind == 'audio' && event.streams.isNotEmpty) {
        _remoteStream = event.streams.first;
        await Helper.setSpeakerphoneOn(true);
        onStatus?.call('Connected · live audio');
      }
    };
    if (_broadcast && _localStream != null) {
      for (final track in _localStream!.getTracks()) { await _pc!.addTrack(track, _localStream!); }
    }
  }

  Future<void> _makeOffer() async {
    if (_pc == null || _stopped) return;
    final offer = await _pc!.createOffer({'offerToReceiveAudio': true, 'offerToReceiveVideo': false});
    await _pc!.setLocalDescription(offer);
    _socket?.emit('offer', {'code': _room, 'sdp': offer.toMap()});
  }
  Future<void> _receiveOffer(Map<String, dynamic> data) async {
    if (_pc == null || _stopped) return;
    await _pc!.setRemoteDescription(RTCSessionDescription(data['sdp']['sdp'] as String, data['sdp']['type'] as String));
    for (final c in _pendingIce) { await _pc!.addCandidate(c); } _pendingIce.clear();
    final answer = await _pc!.createAnswer({'offerToReceiveAudio': true, 'offerToReceiveVideo': false});
    await _pc!.setLocalDescription(answer);
    _socket?.emit('answer', {'code': _room, 'sdp': answer.toMap()});
  }
  Future<void> _receiveAnswer(Map<String, dynamic> data) async {
    if (_pc == null || _stopped) return;
    await _pc!.setRemoteDescription(RTCSessionDescription(data['sdp']['sdp'] as String, data['sdp']['type'] as String));
    for (final c in _pendingIce) { await _pc!.addCandidate(c); } _pendingIce.clear();
  }
  Future<void> _receiveIce(Map<String, dynamic> data) async {
    if (_pc == null || data['candidate'] == null) return;
    final m = Map<String, dynamic>.from(data['candidate'] as Map);
    final c = RTCIceCandidate(m['candidate'] as String?, m['sdpMid'] as String?, m['sdpMLineIndex'] as int?);
    if (await _pc!.getRemoteDescription() == null) { _pendingIce.add(c); } else { await _pc!.addCandidate(c); }
  }

  Future<void> setMuted(bool value) async {
    _muted = value;
    for (final track in _localStream?.getAudioTracks() ?? <MediaStreamTrack>[]) { track.enabled = !value; }
  }
  Future<void> setGain(double value) async { _gain = value; /* Native audio processing gain is platform-specific; see README limitations. */ }
  Future<void> setVolume(double value) async { _volume = value; /* System playback volume is not app-local on every platform; see README. */ }
  Future<void> setRecording(bool value) async {
    if (value) throw UnsupportedError('Remote-track recording is not implemented in this starter. Recording UI is consent-gated; native recording pipeline is a next milestone.');
  }
  Future<void> stop() async {
    _stopped = true;
    try { if (_room != null && _socket?.connected == true) _socket!.emit('leave-room', {'code': _room}); } catch (_) {}
    await _pc?.close(); _pc = null;
    for (final t in _localStream?.getTracks() ?? <MediaStreamTrack>[]) { await t.stop(); }
    await _localStream?.dispose(); _localStream = null;
    await _remoteStream?.dispose(); _remoteStream = null;
    _socket?.disconnect(); _socket?.dispose(); _socket = null;
    _room = null; _pendingIce.clear();
    onStatus?.call('Stopped'); onRoom?.call(''); onLatency?.call(null);
  }
  Future<void> dispose() => stop();
}
